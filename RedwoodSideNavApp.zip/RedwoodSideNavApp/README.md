# Redwood Side Navigation App

## Overview
customer portal

## Features
- **Reactive Maintenance**: View and manage reactive maintenance tasks.
- **Planned Maintenance**: Access planned maintenance schedules and details.
- **Log Service Request**: Submit service requests and view submitted requests.
- **Assets**: View and manage assets related to maintenance tasks.

## Project Structure
```
RedwoodSideNavApp
├── src
│   ├── MainForm.vb
│   ├── Navigation
│   │   └── SideDrawer.vb
│   ├── Pages
│   │   ├── ReactiveMaintenance.vb
│   │   ├── PlannedMaintenance.vb
│   │   ├── LogServiceRequest.vb
│   │   └── Assets.vb
│   └── Services
│       ├── ReactiveMaintenanceService.vb
│       ├── PlannedMaintenanceService.vb
│       ├── LogServiceRequestService.vb
│       └── AssetsService.vb
├── RedwoodSideNavApp.vbproj
└── README.md
```


## Mock REST Services
The application includes mock REST services for data retrieval:
- `services/reactive.json`: Data for reactive maintenance tasks.
- `services/planned.json`: Data for planned maintenance schedules.
- `services/requests.json`: Data for service requests.
- `services/assets.json`: Data for asset management.

