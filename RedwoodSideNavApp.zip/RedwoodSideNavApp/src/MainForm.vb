Imports System.Windows.Forms

Public Class MainForm
    Inherits Form

    Private sideDrawer As SideDrawer

    Public Sub New()
        InitializeComponent()
        sideDrawer = New SideDrawer()
        Me.Controls.Add(sideDrawer)
        Me.Text = "Redwood Side Navigation App"
        Me.Size = New Size(800, 600)
    End Sub

    Private Sub InitializeComponent()
        ' Initialize form components here
    End Sub

    Public Sub NavigateTo(page As String)
        ' Logic to navigate to the selected page
    End Sub
End Class