Imports System.Windows.Forms

Public Class SideDrawer
    Inherits UserControl

    Private Sub SideDrawer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initialize the side navigation drawer and menu items
        InitializeDrawer()
    End Sub

    Private Sub InitializeDrawer()
        ' Create menu items
        Dim menuItems As New List(Of String) From {
            "Reactive Maintenance",
            "Planned Maintenance",
            "Log Service Request",
            "Assets"
        }

        ' Add menu items to the drawer
        For Each item As String In menuItems
            Dim menuItem As New ToolStripMenuItem(item)
            AddHandler menuItem.Click, AddressOf MenuItem_Click
            ' Assuming there's a ToolStrip or similar control to hold the menu items
            ToolStrip1.Items.Add(menuItem)
        Next
    End Sub

    Private Sub MenuItem_Click(sender As Object, e As EventArgs)
        Dim selectedItem As String = CType(sender, ToolStripMenuItem).Text
        NavigateToPage(selectedItem)
    End Sub

    Private Sub NavigateToPage(pageName As String)
        ' Logic to navigate to the respective page based on the selected menu item
        Select Case pageName
            Case "Reactive Maintenance"
                ' Navigate to ReactiveMaintenance page
                MainForm.LoadPage(New ReactiveMaintenance())
            Case "Planned Maintenance"
                ' Navigate to PlannedMaintenance page
                MainForm.LoadPage(New PlannedMaintenance())
            Case "Log Service Request"
                ' Navigate to LogServiceRequest page
                MainForm.LoadPage(New LogServiceRequest())
            Case "Assets"
                ' Navigate to Assets page
                MainForm.LoadPage(New Assets())
        End Select
    End Sub
End Class