Imports System.Net.Http
Imports System.Threading.Tasks
Imports Newtonsoft.Json

Public Class ReactiveMaintenanceService
    Private ReadOnly httpClient As HttpClient

    Public Sub New()
        httpClient = New HttpClient()
    End Sub

    Public Async Function GetReactiveMaintenanceDataAsync() As Task(Of List(Of ReactiveMaintenanceItem))
        Dim response As HttpResponseMessage = Await httpClient.GetAsync("services/reactive.json")
        response.EnsureSuccessStatusCode()

        Dim jsonData As String = Await response.Content.ReadAsStringAsync()
        Dim reactiveMaintenanceItems As List(Of ReactiveMaintenanceItem) = JsonConvert.DeserializeObject(Of List(Of ReactiveMaintenanceItem))(jsonData)

        Return reactiveMaintenanceItems
    End Function
End Class

Public Class ReactiveMaintenanceItem
    Public Property Id As Integer
    Public Property Description As String
    Public Property Status As String
    Public Property DateReported As DateTime
End Class