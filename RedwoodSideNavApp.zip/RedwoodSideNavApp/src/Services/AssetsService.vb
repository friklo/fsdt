Imports System.Net.Http
Imports System.Threading.Tasks
Imports Newtonsoft.Json

Public Class AssetsService
    Private ReadOnly httpClient As HttpClient

    Public Sub New()
        httpClient = New HttpClient()
    End Sub

    Public Async Function GetAssetsAsync() As Task(Of List(Of Asset))
        Dim response As HttpResponseMessage = Await httpClient.GetAsync("services/assets.json")
        response.EnsureSuccessStatusCode()
        Dim jsonResponse As String = Await response.Content.ReadAsStringAsync()
        Return JsonConvert.DeserializeObject(Of List(Of Asset))(jsonResponse)
    End Function
End Class

Public Class Asset
    Public Property Id As Integer
    Public Property Name As String
    Public Property Description As String
    Public Property Value As Decimal
End Class