Imports System.Net.Http
Imports System.Text
Imports System.Threading.Tasks
Imports Newtonsoft.Json

Public Class LogServiceRequestService
    Private ReadOnly httpClient As HttpClient

    Public Sub New()
        httpClient = New HttpClient()
    End Sub

    Public Async Function SubmitServiceRequest(request As ServiceRequest) As Task(Of Boolean)
        Dim json As String = JsonConvert.SerializeObject(request)
        Dim content As New StringContent(json, Encoding.UTF8, "application/json")

        Dim response As HttpResponseMessage = Await httpClient.PostAsync("services/requests.json", content)
        Return response.IsSuccessStatusCode
    End Function

    Public Async Function GetServiceRequests() As Task(Of List(Of ServiceRequest))
        Dim response As HttpResponseMessage = Await httpClient.GetAsync("services/requests.json")
        If response.IsSuccessStatusCode Then
            Dim json As String = Await response.Content.ReadAsStringAsync()
            Return JsonConvert.DeserializeObject(Of List(Of ServiceRequest))(json)
        End If
        Return New List(Of ServiceRequest)()
    End Function
End Class

Public Class ServiceRequest
    Public Property Id As Integer
    Public Property Description As String
    Public Property RequestDate As DateTime
    Public Property Status As String
End Class