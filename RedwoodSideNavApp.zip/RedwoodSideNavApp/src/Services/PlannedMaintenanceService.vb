Imports System.Net.Http
Imports System.Threading.Tasks
Imports Newtonsoft.Json

Public Class PlannedMaintenanceService
    Private ReadOnly httpClient As HttpClient

    Public Sub New()
        httpClient = New HttpClient()
    End Sub

    Public Async Function GetPlannedMaintenanceDataAsync() As Task(Of List(Of PlannedMaintenanceItem))
        Dim response As HttpResponseMessage = Await httpClient.GetAsync("services/planned.json")
        response.EnsureSuccessStatusCode()

        Dim jsonData As String = Await response.Content.ReadAsStringAsync()
        Dim plannedMaintenanceItems As List(Of PlannedMaintenanceItem) = JsonConvert.DeserializeObject(Of List(Of PlannedMaintenanceItem))(jsonData)

        Return plannedMaintenanceItems
    End Function
End Class

Public Class PlannedMaintenanceItem
    Public Property Id As Integer
    Public Property Description As String
    Public Property ScheduledDate As DateTime
    Public Property Status As String
End Class