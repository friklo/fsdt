Imports System.Windows.Forms

Public Class PlannedMaintenance
    Inherits UserControl

    Private dataGridView As DataGridView

    Public Sub New()
        InitializeComponent()
        LoadData()
    End Sub

    Private Sub InitializeComponent()
        Me.dataGridView = New DataGridView()
        Me.SuspendLayout()
        
        ' 
        ' dataGridView
        ' 
        Me.dataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dataGridView.Dock = DockStyle.Fill
        Me.dataGridView.Location = New Point(0, 0)
        Me.dataGridView.Name = "dataGridView"
        Me.dataGridView.Size = New Size(800, 450)
        Me.dataGridView.TabIndex = 0
        
        ' 
        ' PlannedMaintenance
        ' 
        Me.Controls.Add(Me.dataGridView)
        Me.Name = "PlannedMaintenance"
        Me.Size = New Size(800, 450)
        Me.ResumeLayout(False)
    End Sub

    Private Sub LoadData()
        ' Code to fetch and bind data from PlannedMaintenanceService
        Dim service As New PlannedMaintenanceService()
        Dim data As DataTable = service.GetPlannedMaintenanceData()
        dataGridView.DataSource = data
    End Sub
End Class