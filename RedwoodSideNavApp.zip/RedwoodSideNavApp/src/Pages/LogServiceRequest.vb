Imports System.Windows.Forms

Public Class LogServiceRequest
    Inherits Form

    Private requestTable As DataGridView
    Private submitButton As Button
    Private requestTextBox As TextBox

    Public Sub New()
        InitializeComponent()
        LoadRequests()
    End Sub

    Private Sub InitializeComponent()
        Me.requestTable = New DataGridView()
        Me.submitButton = New Button()
        Me.requestTextBox = New TextBox()

        ' 
        ' requestTable
        ' 
        Me.requestTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.requestTable.Location = New Point(12, 12)
        Me.requestTable.Name = "requestTable"
        Me.requestTable.Size = New Size(400, 200)
        Me.requestTable.TabIndex = 0

        ' 
        ' requestTextBox
        ' 
        Me.requestTextBox.Location = New Point(12, 220)
        Me.requestTextBox.Name = "requestTextBox"
        Me.requestTextBox.Size = New Size(300, 20)
        Me.requestTextBox.TabIndex = 1

        ' 
        ' submitButton
        ' 
        Me.submitButton.Location = New Point(320, 220)
        Me.submitButton.Name = "submitButton"
        Me.submitButton.Size = New Size(75, 23)
        Me.submitButton.TabIndex = 2
        Me.submitButton.Text = "Submit"
        Me.submitButton.UseVisualStyleBackColor = True
        AddHandler Me.submitButton.Click, AddressOf Me.SubmitButton_Click

        ' 
        ' LogServiceRequest
        ' 
        Me.ClientSize = New Size(424, 261)
        Me.Controls.Add(Me.requestTable)
        Me.Controls.Add(Me.requestTextBox)
        Me.Controls.Add(Me.submitButton)
        Me.Name = "LogServiceRequest"
        Me.Text = "Log Service Request"
    End Sub

    Private Sub LoadRequests()
        ' Logic to load requests from LogServiceRequestService
    End Sub

    Private Sub SubmitButton_Click(sender As Object, e As EventArgs)
        ' Logic to submit the request using LogServiceRequestService
    End Sub
End Class